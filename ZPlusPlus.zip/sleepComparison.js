average =localStorage.getItem("averageSleepKey");
 document.getElementById("average").innerText = "Over the past 7 days, you've gotten an average of " + average + " hours of sleep";