var average = localStorage.getItem("averageSleepKey");
document.getElementById("average").innerText = "Over the past 7 days, you've gotten an average of " + average + " hours of sleep per day";

if (average < 8)
{
  document.getElementById("recommendation").innerText = "You should really get more sleep...";
}
else if (average >= 8)
{
  document.getElementById("recommendation").innerText = "You're getting enough sleep.";
}