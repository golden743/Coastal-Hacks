averagesleep =localStorage.getItem("averageSleepKey");
var rank;
if(averagesleep>12){
  rank="HACKER";
}

if(averagesleep==12){
  rank="SLEEP GOD";
}
if(averagesleep==11){
  rank="Legendary";
}
if(averagesleep==10){
  rank="Amazing";
}
if(averagesleep==9){
  rank="Great";
}
if(averagesleep==8){
  rank="Decent";
}
if(averagesleep==7){
  rank="Poor";
}
if(averagesleep<=6){
  rank="Zombie";
}

document.getElementById("ranking").innerText = ("Rank: " + rank);