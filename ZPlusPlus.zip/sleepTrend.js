_sleepTimes = localStorage.getItem("sleepTimesKey");
_sleepTimes.toString;
_sleepTimes = _sleepTimes.split(',');


function getpx(length){
  return (length*100).toString() + "px" ; //Puts a space in front of output
}

document.getElementById("square1").style.width = getpx(_sleepTimes[0]);
document.getElementById("square2").style.width = getpx(_sleepTimes[1]);
document.getElementById("square3").style.width = getpx(_sleepTimes[2]);
document.getElementById("square4").style.width = getpx(_sleepTimes[3]);
document.getElementById("square5").style.width = getpx(_sleepTimes[4]);
document.getElementById("square6").style.width = getpx(_sleepTimes[5]);
document.getElementById("square7").style.width = getpx(_sleepTimes[6]);

var missing = false;
for (i=0; i<_sleepTimes.length; i++){
  if(_sleepTimes[i]==""){
    missing=true;
  }

}

if (missing==true)
{  
  document.getElementById("explanation").innerText = "It looks like you don't have a complete set of data. Go back to the home page and enter in a number for all 7 days to see a full graph.";
}