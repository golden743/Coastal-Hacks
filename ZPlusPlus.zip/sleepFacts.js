document.getElementById("analysis").innerText = localStorage.getItem("averageSleepKey");
