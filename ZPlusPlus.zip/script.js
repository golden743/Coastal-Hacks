//Created outside function so they're not local
var sleepTimes = [];
var averageSleep = 0;

function getSleepTime(){

  sleepTimes = []; //Reset variables
  averageSleep = 0;

  sleepTimes.push(document.getElementById('myinput1').value);
  sleepTimes.push(document.getElementById('myinput2').value);
  sleepTimes.push(document.getElementById('myinput3').value);
  sleepTimes.push(document.getElementById('myinput4').value);
  sleepTimes.push(document.getElementById('myinput5').value);
  sleepTimes.push(document.getElementById('myinput6').value);
  sleepTimes.push(document.getElementById('myinput7').value);  

  for (i=0; i<sleepTimes.length; i++){
    averageSleep += Number(sleepTimes[i]);

  }
  averageSleep /= sleepTimes.length;
  averageSleep = Math.round(averageSleep);
  
  if (isFinite(averageSleep) == false){
    alert("Please enter only numbers in the data field");
    averageSleep="Bad Data";
  }
  localStorage.setItem("averageSleepKey", averageSleep);
  localStorage.setItem("sleepTimesKey", sleepTimes);
  

}